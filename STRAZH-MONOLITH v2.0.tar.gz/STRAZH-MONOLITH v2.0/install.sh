#!/bin/bash
echo "[*] Установка компонентов системы СТРАЖ..."
sudo apt update
sudo apt install arp-scan nmap nbtscan python3 -y
echo "[+] Установка завершена. Система готова к работе."
