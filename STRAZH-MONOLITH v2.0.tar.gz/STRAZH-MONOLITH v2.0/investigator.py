import sys, subprocess

def run(ip):
    print(f"[*] СЛЕДОВАТЕЛЬ: Сбор досье на {ip}...")
    nmap_data = subprocess.getoutput(f"sudo nmap -sV -O --version-light {ip}")
    nb_data = subprocess.getoutput(f"nbtscan -r {ip}")
    report = f"TARGET: {ip}\n\n[NMAP]\n{nmap_data}\n\n[NETBIOS]\n{nb_data}"
    fname = f"raw_{ip.replace('.', '_')}.txt"
    with open(fname, "w") as f: f.write(report)
    print(f"[+] Отчет сохранен: {fname}")

if __name__ == "__main__":
    if len(sys.argv) > 1: run(sys.argv[1])
    else: print("Введите IP.")
