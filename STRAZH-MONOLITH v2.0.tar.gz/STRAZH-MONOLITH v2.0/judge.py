import sys

def process(path):
    try:
        with open(path, 'r') as f: data = f.read()
        print("\n=== ЗАПРОС ДЛЯ ГЛОБАЛЬНОГО ИИ ===")
        print(f"Проанализируй данные сканирования. Определи тип устройства, его потенциальную опасность и дай рекомендации по защите:\n\n{data}")
        print("=================================")
    except: print("Файл не найден.")

if __name__ == "__main__":
    if len(sys.argv) > 1: process(sys.argv[1])
    else: print("Укажите путь к отчету.")
