import os, time, subprocess, re

def get_interface():
    cmd = "ip route | grep default | awk '{print $5}'"
    res = subprocess.getoutput(cmd).strip()
    return res if res else "wlan0"

def main():
    iface = get_interface()
    print(f"[*] МОНИТОР заступил на дежурство ({iface})...")
    known = set()
    while True:
        try:
            res = subprocess.check_output(f"sudo arp-scan --interface={iface} --localnet", shell=True).decode('utf-8')
            devs = re.findall(r'(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-f:]{17})', res)
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            with open("network_history.log", "a") as f:
                for ip, mac in devs:
                    f.write(f"[{ts}] {ip} | {mac}\n")
                    if mac not in known:
                        print(f"[!] ОБНАРУЖЕН: {ip} | {mac}")
                        known.add(mac)
            time.sleep(60)
        except: time.sleep(10)

if __name__ == "__main__": main()
